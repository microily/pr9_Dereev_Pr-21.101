package com.example.pr9_pr_21101_dereev;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Steps extends AppCompatActivity implements View.OnClickListener{

    Button button9;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_steps);
        button9 =(Button)findViewById(R.id.button9);
        button9.setOnClickListener(this);
    }
    @Override
    public void onClick(View view) {
        Intent intent = new Intent(this, Syte.class);
        startActivity(intent);
    }
}